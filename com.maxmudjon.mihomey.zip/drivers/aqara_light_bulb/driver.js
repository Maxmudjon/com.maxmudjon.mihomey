const Homey = require("homey");

class AqaraLightBulb extends Homey.Driver {}

module.exports = AqaraLightBulb;
